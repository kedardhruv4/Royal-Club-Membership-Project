<?php
include "admin_header.php";

?>

<section >
<br><br><br><br>
<div class="container">				
<div class="row">
<div class="col-sm-3"></div>
<div class="col-md-6">
<center>
<table class="table table-hover table-bordered " >

<h1 class="bg-warning">Report Data</h1>
<tr><td><a href="viewcountry.php?act=1"><h3>All Country</h3></a></td></tr>
<tr><td><a href="viewstate.php?act=1"><h3>All State</h3></a></td></tr>
<tr><td><a href="viewresort.php?act=1"><h3>All Resort</h3></a></td></tr>
<tr><td><a href="viewroom.php?act=1"><h3>All Room</h3></a></td></tr>
</table></center>
</div>
</div>
</div>
</section>
</body>
</html>