<?php
include "admin_header.php";

?>
<!--================Banner Area =================-->
        <section class="banner_area">
            <div class="booking_table d_flex align-items-center">
            	<div class="overlay bg-parallax" data-stellar-ratio="0.9" data-stellar-vertical-offset="0" data-background=""></div>
				<div class="container">
					<div class="banner_content text-center">
						<h6>ADMIN PANEL</h6>
						<h2>ROYAL CLUB</h2>
						<h6>From here Admin can Insert,update<br>and manage Whole Website</h6>
					</div>
				</div>
            </div>
            
        </section>
        <!--================Banner Area =================-->
        